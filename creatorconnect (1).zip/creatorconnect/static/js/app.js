/* CreatorConnect AI - single-page frontend (no framework). */
"use strict";

const NICHES = ["Tech", "Fashion", "Beauty", "Fitness", "Food", "Gaming", "Travel", "Finance", "Education", "Lifestyle"];
const PLATFORMS = ["Instagram", "YouTube", "TikTok", "X", "LinkedIn", "Pinterest", "Twitch"];
const TONES = ["Friendly", "Professional", "Playful", "Bold", "Inspirational", "Luxury"];
const CONTENT_TYPES = ["Short-form video", "Product reviews", "Tutorials", "Live streaming", "Blog / carousel", "Photography"];

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const state = { user: null };

/* ---------- Safe templating: every interpolated value is HTML-escaped ---------- */
class Raw { constructor(s) { this.s = s; } }
const raw = (s) => new Raw(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const toStr = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(toStr).join("") : esc(v));
const html = (strs, ...vals) => new Raw(strs.reduce((a, s, i) => a + s + (i < vals.length ? toStr(vals[i]) : ""), ""));

/* ---------- Helpers ---------- */
async function api(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch("/api" + path, {
      method,
      headers: body !== undefined ? { "Content-Type": "application/json" } : (method === "GET" ? {} : { "Content-Type": "application/json" }),
      body: body !== undefined ? JSON.stringify(body) : (method === "GET" || method === "DELETE" ? undefined : "{}"),
      credentials: "same-origin",
    });
  } catch {
    throw new Error("Cannot reach the server. Check your connection and try again.");
  }
  let data = {};
  try { data = await res.json(); } catch { /* non-JSON */ }
  if (!res.ok) {
    const e = new Error(data.error || "Something went wrong. Please try again.");
    e.status = res.status;
    throw e;
  }
  return data;
}

function toast(msg, type = "ok") {
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = msg;
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

async function copyText(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand("copy"); } catch { /* ignore */ }
    ta.remove();
  }
  toast("Copied to clipboard");
  if (btn) { const o = btn.textContent; btn.textContent = "Copied!"; setTimeout(() => (btn.textContent = o), 1200); }
}

const initials = (n) => (n || "?").split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
const money = (n) => "₹" + Number(n || 0).toLocaleString("en-IN");
const budgetRange = (c) => (c.rate_min || c.rate_max ? (c.rate_max > c.rate_min ? `${money(c.rate_min)} - ${money(c.rate_max)}` : money(c.rate_min)) : "Not listed");
const options = (list, selected = "", blank) => html`${blank ? html`<option value="">${blank}</option>` : ""}${list.map((o) => html`<option value="${o}" ${o === selected ? raw("selected") : ""}>${o}</option>`)}`;
const formData = (form) => Object.fromEntries(new FormData(form).entries());
const banner = (msg, type = "error") => html`<div class="banner ${type}" role="${type === "error" ? "alert" : "status"}">${msg}</div>`;

function render(view) {
  const app = $("#app");
  app.innerHTML = `<div class="fade">${toStr(view)}</div>`;
  window.scrollTo({ top: 0 });
}

function setBusy(btn, busy, label) {
  if (!btn) return;
  btn.disabled = busy;
  if (busy) { btn.dataset.label = btn.innerHTML; btn.innerHTML = '<span class="spinner" aria-hidden="true"></span> ' + esc(label || "Working..."); }
  else if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
}

function showError(container, e) {
  container.innerHTML = toStr(banner(e.message || String(e)));
}

/* ---------- Navigation ---------- */
function renderNav() {
  const u = state.user;
  const links = [["#/discover", "Discover"], ["#/content", "AI Content"]];
  if (!u || u.role === "creator") links.push(["#/builder", "Portfolio Builder"]);
  if (!u || u.role === "brand") links.push(["#/match", "Smart Match"]);
  if (u) links.push(["#/dashboard", "Dashboard"]);
  const cur = location.hash || "#/";
  const nav = $("#navLinks");
  nav.innerHTML = toStr(html`
    ${links.map(([h, t]) => html`<a href="${h}" class="${cur.startsWith(h) ? "active" : ""}">${t}</a>`)}
    ${u ? html`<button id="logoutBtn" type="button">Log out (${u.name.split(" ")[0]})</button>`
        : html`<a href="#/login">Log in</a><a href="#/register" class="btn btn-primary btn-sm">Sign up</a>`}`);
  const lo = $("#logoutBtn");
  if (lo) lo.onclick = async () => { await api("/auth/logout", { method: "POST" }); state.user = null; toast("Logged out"); location.hash = "#/"; renderNav(); };
}

$("#menuBtn").addEventListener("click", () => {
  const nav = $("#navLinks");
  const open = nav.classList.toggle("open");
  $("#menuBtn").setAttribute("aria-expanded", String(open));
});

/* ---------- Components ---------- */
function creatorCard(c) {
  return html`
  <article class="card hover">
    <div class="row" style="flex-wrap:nowrap">
      <div class="avatar" aria-hidden="true">${initials(c.name)}</div>
      <div><h3 style="margin:0">${c.name}</h3><div class="muted small">${c.headline || c.niche}</div></div>
    </div>
    <div class="chips"><span class="chip niche">${c.niche}</span>${c.platforms.map((p) => html`<span class="chip plat">${p}</span>`)}</div>
    <div class="chips">${c.skills.slice(0, 4).map((s) => html`<span class="chip">${s}</span>`)}</div>
    <p class="small muted">Budget: <strong style="color:var(--text)">${budgetRange(c)}</strong> per project</p>
    <a class="btn btn-sm" href="#/creator/${c.id}">View profile &amp; portfolio</a>
  </article>`;
}

function requireRole(role) {
  if (!state.user) {
    render(html`<div class="empty"><h2>Please log in</h2><p>You need an account to use this page.</p>
      <a class="btn btn-primary" href="#/login">Log in</a> <a class="btn" href="#/register">Create account</a></div>`);
    return false;
  }
  if (role && state.user.role !== role) {
    render(html`<div class="empty"><h2>${role === "brand" ? "Brands only" : "Creators only"}</h2>
      <p>This page is available to ${role} accounts. You are logged in as a ${state.user.role}.</p><a class="btn" href="#/dashboard">Go to dashboard</a></div>`);
    return false;
  }
  return true;
}

/* ---------- Views ---------- */
async function viewHome() {
  render(html`
  <section class="hero">
    <p class="chip niche" style="display:inline-block">AI-powered creator marketplace</p>
    <h1>Where <span class="grad-text">AI creators</span> meet the brands that need them</h1>
    <p>Discover creators, build an AI-written portfolio, generate campaign content and get transparent creator-to-campaign matches.</p>
    <div class="row">
      <a class="btn btn-primary" href="#/discover">Find creators</a>
      <a class="btn" href="#/register">Join as a creator</a>
      <a class="btn" href="#/content">Try the AI content generator</a>
    </div>
  </section>
  <section class="section"><div class="grid">
    ${[["Creator Discovery", "Search and filter by niche, platform, skills and budget.", "#/discover"],
       ["AI Portfolio Builder", "Turn a few details into a professional headline, intro and portfolio.", "#/builder"],
       ["AI Content Generator", "Captions, ideas, briefs and hashtags in seconds.", "#/content"],
       ["Smart Matching", "Transparent scores that explain why each creator fits.", "#/match"]]
      .map(([t, d, h]) => html`<a class="card hover" href="${h}" style="color:inherit;text-decoration:none"><h3>${t}</h3><p class="muted">${d}</p><span>Open &rarr;</span></a>`)}
  </div></section>
  <section class="section"><h2>Featured creators</h2><div id="featured" class="grid"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div></section>
  <section class="section card">
    <h2>Try the demo</h2>
    <p class="muted">Log in with a demo account (password <code>Demo@1234</code>): <strong>demo.creator@creatorconnect.ai</strong> or <strong>demo.brand@creatorconnect.ai</strong>.</p>
    <a class="btn btn-primary" href="#/login">Go to login</a>
  </section>`);
  try {
    const { creators } = await api("/creators?limit=3");
    $("#featured").innerHTML = toStr(creators.map(creatorCard));
  } catch (e) { showError($("#featured"), e); }
}

async function viewDiscover() {
  render(html`
  <div class="page-head"><h1>Discover creators</h1><p>Search by name or skill, then narrow down by niche, platform and budget.</p></div>
  <form id="filters" class="filters" role="search" aria-label="Creator filters">
    <div><label for="f-q">Search</label><input id="f-q" name="q" type="search" placeholder="Name, skill, keyword"></div>
    <div><label for="f-niche">Niche</label><select id="f-niche" name="niche">${options(NICHES, "", "All niches")}</select></div>
    <div><label for="f-platform">Platform</label><select id="f-platform" name="platform">${options(PLATFORMS, "", "All platforms")}</select></div>
    <div><label for="f-skill">Skill</label><input id="f-skill" name="skill" placeholder="e.g. Reels"></div>
    <div><label for="f-budget">Max budget (₹)</label><input id="f-budget" name="max_budget" type="number" min="0" step="1000" placeholder="Any"></div>
    <button type="button" id="reset" class="btn">Reset</button>
  </form>
  <p id="count" class="muted small" aria-live="polite"></p>
  <div id="results" class="grid"></div>`);
  const form = $("#filters"), results = $("#results");
  let timer, seq = 0;
  async function load() {
    const my = ++seq;
    results.innerHTML = toStr(html`<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>`);
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(formData(form))) if (String(v).trim()) params.set(k, String(v).trim());
    try {
      const { creators } = await api("/creators?" + params);
      if (my !== seq) return;
      $("#count").textContent = `${creators.length} creator${creators.length === 1 ? "" : "s"} found`;
      results.innerHTML = creators.length ? toStr(creators.map(creatorCard)) :
        toStr(html`<div class="empty" style="grid-column:1/-1"><h3>No creators match your search</h3>
          <p>Try removing a filter, increasing the budget, or searching a broader keyword.</p></div>`);
    } catch (e) { if (my === seq) showError(results, e); }
  }
  form.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(load, 250); });
  form.addEventListener("submit", (e) => e.preventDefault());
  $("#reset").onclick = () => { form.reset(); load(); };
  load();
}

async function viewCreator(id) {
  render(html`<div class="skeleton"></div>`);
  try {
    const { creator: c } = await api("/creators/" + id);
    const isBrand = state.user && state.user.role === "brand";
    render(html`
    <a href="#/discover" class="muted small">&larr; Back to creators</a>
    <section class="card section" style="margin-top:12px">
      <div class="row" style="flex-wrap:nowrap;align-items:flex-start">
        <div class="avatar lg" aria-hidden="true">${initials(c.name)}</div>
        <div><h1 style="font-size:2rem;margin:0">${c.name}</h1><p class="muted" style="font-size:1.1rem">${c.headline}</p>
          <div class="chips"><span class="chip niche">${c.niche}</span>${c.platforms.map((p) => html`<span class="chip plat">${p}</span>`)}
          <span class="chip">${c.experience_years} yrs experience</span></div></div>
      </div>
      ${isBrand ? html`<div class="row"><button id="saveBtn" class="btn ${c.saved ? "" : "btn-primary"}" type="button">${c.saved ? "Saved ✓ (click to remove)" : "Save creator"}</button>
        <a class="btn" href="#/match">Use in Smart Match</a></div>` : ""}
    </section>
    <div class="grid-2 section">
      <section class="card"><h2>About</h2><p>${c.intro || "No introduction yet."}</p><h3>Portfolio</h3><p class="pre">${c.portfolio_description || "No portfolio description yet."}</p></section>
      <section class="card"><h2>Details</h2>
        <p><strong>Budget:</strong> ${budgetRange(c)} per project</p>
        <p><strong>Audience:</strong> ${c.audience || "Not listed"}</p>
        <h3>Skills</h3><div class="chips">${c.skills.map((s) => html`<span class="chip">${s}</span>`)}</div>
        <h3>Sample work</h3><p class="pre">${c.sample_work || "No samples listed."}</p>
        ${/^https?:\/\//.test(c.portfolio_url) ? html`<a class="btn btn-sm" href="${c.portfolio_url}" target="_blank" rel="noopener noreferrer">Visit portfolio &#8599;</a>` : ""}
      </section>
    </div>`);
    const sb = $("#saveBtn");
    if (sb) sb.onclick = async () => {
      try {
        await api("/saved/" + id, { method: c.saved ? "DELETE" : "POST" });
        toast(c.saved ? "Removed from saved" : "Creator saved");
        viewCreator(id);
      } catch (e) { toast(e.message, "error"); }
    };
  } catch (e) {
    render(html`<div class="empty"><h2>Creator not found</h2><p>${e.message}</p><a class="btn" href="#/discover">Back to discovery</a></div>`);
  }
}

async function viewBuilder() {
  if (!requireRole("creator")) return;
  let p;
  try { ({ profile: p } = await api("/profile")); } catch (e) { return render(banner(e.message)); }
  render(html`
  <div class="page-head"><h1>AI Portfolio Builder</h1><p>Tell us about yourself, let AI draft your headline, intro and portfolio, then edit and save. Saving publishes your profile to the marketplace.</p></div>
  <div class="grid-2">
    <form id="pf" class="card form" novalidate>
      <div class="form-grid">
        <div><label for="b-name">Name *</label><input id="b-name" name="name" required value="${p.name}"></div>
        <div><label for="b-niche">Niche *</label><input id="b-niche" name="niche" list="niches" required value="${p.niche}"><datalist id="niches">${NICHES.map((n) => html`<option value="${n}">`)}</datalist></div>
      </div>
      <div><label for="b-skills">Skills * (comma separated)</label><input id="b-skills" name="skills" required value="${p.skills.join(", ")}" placeholder="Reels, Scriptwriting, AI video editing"></div>
      <div class="form-grid">
        <div><label for="b-plat">Platforms (comma separated)</label><input id="b-plat" name="platforms" value="${p.platforms.join(", ")}" placeholder="Instagram, YouTube"></div>
        <div><label for="b-exp">Years of experience</label><input id="b-exp" name="experience_years" type="number" min="0" max="60" value="${p.experience_years}"></div>
        <div><label for="b-min">Min budget (₹)</label><input id="b-min" name="rate_min" type="number" min="0" value="${p.rate_min}"></div>
        <div><label for="b-max">Max budget (₹)</label><input id="b-max" name="rate_max" type="number" min="0" value="${p.rate_max}"></div>
      </div>
      <div><label for="b-aud">Your audience</label><input id="b-aud" name="audience" value="${p.audience}" placeholder="e.g. Women aged 18-30 into sustainable fashion"></div>
      <div><label for="b-sample">Sample work</label><textarea id="b-sample" name="sample_work" placeholder="Describe past projects, results, collaborations">${p.sample_work}</textarea></div>
      <div><label for="b-url">Portfolio link</label><input id="b-url" name="portfolio_url" type="url" value="${p.portfolio_url}" placeholder="https://"></div>
      <hr style="border:0;border-top:1px solid var(--border);width:100%">
      <div class="row"><button type="button" id="genBtn" class="btn btn-primary">&#10024; Generate with AI</button><span class="muted small">Fills the three fields below. You can edit them.</span></div>
      <div id="genMsg"></div>
      <div><label for="b-head">Headline</label><input id="b-head" name="headline" maxlength="160" value="${p.headline}"></div>
      <div><label for="b-intro">Introduction</label><textarea id="b-intro" name="intro" maxlength="600">${p.intro}</textarea></div>
      <div><label for="b-desc">Portfolio description</label><textarea id="b-desc" name="portfolio_description" maxlength="2000">${p.portfolio_description}</textarea></div>
      <div id="formMsg" aria-live="polite"></div>
      <button class="btn btn-primary" type="submit" id="saveBtn">Save profile</button>
    </form>
    <aside class="card" style="align-self:start"><h2>Live preview</h2><div id="preview"></div>${p.published ? html`<a class="btn btn-sm" href="#/creator/${p.id}">View public profile</a>` : html`<p class="muted small">Not published yet. Save to appear in discovery.</p>`}</aside>
  </div>`);
  const form = $("#pf");
  const preview = () => {
    const d = formData(form);
    $("#preview").innerHTML = toStr(html`
      <div class="row" style="flex-wrap:nowrap"><div class="avatar" aria-hidden="true">${initials(d.name)}</div><div><h3 style="margin:0">${d.name || "Your name"}</h3><div class="muted small">${d.headline || "Your headline"}</div></div></div>
      <div class="chips"><span class="chip niche">${d.niche || "Niche"}</span>${String(d.platforms || "").split(",").filter((x) => x.trim()).map((x) => html`<span class="chip plat">${x.trim()}</span>`)}</div>
      <p>${d.intro || "Your introduction will appear here."}</p><p class="muted pre">${d.portfolio_description}</p>
      <div class="chips">${String(d.skills || "").split(",").filter((x) => x.trim()).map((x) => html`<span class="chip">${x.trim()}</span>`)}</div>`);
  };
  form.addEventListener("input", preview); preview();

  $("#genBtn").onclick = async (ev) => {
    const btn = ev.currentTarget, msg = $("#genMsg"); msg.innerHTML = "";
    setBusy(btn, true, "Generating...");
    try {
      const r = await api("/profile/generate", { method: "POST", body: formData(form) });
      form.headline.value = r.headline; form.intro.value = r.intro; form.portfolio_description.value = r.portfolio_description;
      if (r.mode === "demo") msg.innerHTML = toStr(banner("DEMO MODE: " + r.notice, "demo"));
      else toast("Portfolio generated - review and save");
      preview();
    } catch (e) { msg.innerHTML = toStr(banner(e.message)); }
    setBusy(btn, false);
  };
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#saveBtn"), msg = $("#formMsg"); msg.innerHTML = "";
    setBusy(btn, true, "Saving...");
    try {
      const { profile } = await api("/profile", { method: "PUT", body: formData(form) });
      toast("Profile saved");
      location.hash = "#/creator/" + profile.id;
    } catch (err) { msg.innerHTML = toStr(banner(err.message)); setBusy(btn, false); }
  });
}

function viewContent() {
  render(html`
  <div class="page-head"><h1>AI Content Generator</h1><p>Create captions, content ideas, a campaign brief and hashtags for any product.</p></div>
  <div class="grid-2">
    <form id="cf" class="card form" novalidate>
      <div><label for="c-prod">Product *</label><input id="c-prod" name="product" required maxlength="200" placeholder="e.g. EcoBottle reusable water bottle"></div>
      <div><label for="c-topic">Campaign topic *</label><input id="c-topic" name="topic" required maxlength="200" placeholder="e.g. Plastic-free summer"></div>
      <div><label for="c-aud">Target audience *</label><input id="c-aud" name="audience" required maxlength="200" placeholder="e.g. College students in metro cities"></div>
      <div class="form-grid">
        <div><label for="c-plat">Platform *</label><select id="c-plat" name="platform">${options(PLATFORMS, "Instagram")}</select></div>
        <div><label for="c-tone">Tone *</label><select id="c-tone" name="tone">${options(TONES, "Friendly")}</select></div>
      </div>
      <div id="cMsg" aria-live="polite"></div>
      <button class="btn btn-primary" id="cBtn" type="submit">&#10024; Generate content</button>
    </form>
    <div id="cOut" class="card"><p class="muted">Your generated content will appear here.</p></div>
  </div>`);
  $("#cf").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#cBtn"), out = $("#cOut"), msg = $("#cMsg"); msg.innerHTML = "";
    const data = formData(e.target);
    if (Object.values(data).some((v) => !String(v).trim())) { msg.innerHTML = toStr(banner("Please fill in every field.")); return; }
    setBusy(btn, true, "Generating...");
    out.innerHTML = toStr(html`<div class="skeleton"></div>`);
    try {
      const r = await api("/content/generate", { method: "POST", body: data });
      const list = (title, items, key) => html`<h3>${title}</h3>${items.map((t) => html`<div class="out-item"><span>${t}</span><button class="btn btn-sm" type="button" data-copy="${t}">Copy</button></div>`)}`;
      out.innerHTML = toStr(html`
        ${r.mode === "demo" ? banner("DEMO MODE: " + r.notice, "demo") : ""}
        ${list("Captions", r.captions)}
        <div class="section" style="margin-top:20px">${list("Content ideas", r.ideas)}</div>
        <div style="margin-top:20px"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Campaign brief</h3><button class="btn btn-sm" type="button" data-copy="${r.brief}">Copy</button></div><p class="pre" style="margin-top:8px">${r.brief}</p></div>
        <div style="margin-top:20px"><div class="row" style="justify-content:space-between"><h3 style="margin:0">Hashtags</h3><button class="btn btn-sm" type="button" data-copy="${r.hashtags.join(" ")}">Copy all</button></div>
        <div class="chips">${r.hashtags.map((h) => html`<span class="chip plat">${h}</span>`)}</div></div>`);
      $$("[data-copy]", out).forEach((b) => (b.onclick = () => copyText(b.dataset.copy, b)));
    } catch (err) {
      out.innerHTML = toStr(html`<p class="muted">Your generated content will appear here.</p>`);
      msg.innerHTML = toStr(banner(err.message));
    }
    setBusy(btn, false);
  });
}

async function viewMatch() {
  if (!requireRole("brand")) return;
  let campaigns = [];
  try { ({ campaigns } = await api("/campaigns")); } catch { /* optional */ }
  render(html`
  <div class="page-head"><h1>Smart Creator Matching</h1><p>Describe your campaign and we rank creators with a transparent scoring formula. Pick one of your campaigns to prefill the form.</p></div>
  <div class="grid-2" style="align-items:start">
    <form id="mf" class="card form" novalidate>
      ${campaigns.length ? html`<div><label for="m-camp">Use an existing campaign</label><select id="m-camp"><option value="">- custom requirements -</option>${campaigns.map((c) => html`<option value="${c.id}">${c.title}</option>`)}</select></div>` : ""}
      <div class="form-grid">
        <div><label for="m-niche">Niche</label><select id="m-niche" name="niche">${options(NICHES, "", "Any")}</select></div>
        <div><label for="m-plat">Platform</label><select id="m-plat" name="platform">${options(PLATFORMS, "", "Any")}</select></div>
        <div><label for="m-budget">Budget (₹)</label><input id="m-budget" name="budget" type="number" min="0" step="1000"></div>
        <div><label for="m-type">Content type</label><input id="m-type" name="content_type" list="ctypes" placeholder="e.g. Short-form video"><datalist id="ctypes">${CONTENT_TYPES.map((t) => html`<option value="${t}">`)}</datalist></div>
      </div>
      <div><label for="m-aud">Target audience</label><input id="m-aud" name="audience" placeholder="e.g. Busy professionals aged 22-40"></div>
      <div><label for="m-desc">Extra details (used for skill matching)</label><textarea id="m-desc" name="description"></textarea></div>
      <div id="mMsg" aria-live="polite"></div>
      <button class="btn btn-primary" id="mBtn" type="submit">Find matching creators</button>
      <details><summary>How scores are calculated</summary>
        <p class="small muted">Niche 35 pts &middot; Platform 20 &middot; Skills 20 &middot; Budget 15 &middot; Audience 10. Fields you leave blank are excluded and the score is rescaled to 100. Each creator shows points per criterion with the reason.</p></details>
    </form>
    <div id="mOut"><div class="empty">Results will appear here.</div></div>
  </div>`);
  const form = $("#mf");
  const sel = $("#m-camp");
  if (sel) sel.onchange = () => {
    const c = campaigns.find((x) => String(x.id) === sel.value);
    if (!c) return;
    form.niche.value = c.niche; form.platform.value = c.platform; form.budget.value = c.budget;
    form.content_type.value = c.content_type; form.audience.value = c.audience; form.description.value = c.description;
  };
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#mBtn"), out = $("#mOut"), msg = $("#mMsg"); msg.innerHTML = "";
    setBusy(btn, true, "Matching...");
    try {
      const r = await api("/match", { method: "POST", body: formData(form) });
      out.innerHTML = toStr(html`
        ${banner("Scores are estimates based on profile data, not guarantees of campaign success.", "info")}
        <div class="grid" style="grid-template-columns:1fr">${r.matches.map((m, i) => matchCard(m, i + 1))}</div>`);
    } catch (err) { msg.innerHTML = toStr(banner(err.message)); }
    setBusy(btn, false);
  });
}

function matchCard(m, rank) {
  const c = m.creator;
  return html`<article class="card">
    <div class="row" style="justify-content:space-between;flex-wrap:nowrap">
      <div class="row" style="flex-wrap:nowrap"><div class="avatar" aria-hidden="true">${initials(c.name)}</div>
        <div><h3 style="margin:0">#${rank} ${c.name}</h3><div class="muted small">${c.niche} &middot; ${c.platforms.join(", ")} &middot; ${budgetRange(c)}</div></div></div>
      <div style="text-align:right"><div class="score">${m.score}%</div><div class="muted small">estimated match</div></div>
    </div>
    <div class="bar" role="img" aria-label="Match score ${m.score} percent" style="margin-top:12px"><i style="width:${m.score}%"></i></div>
    <details><summary>Why this match?</summary>
      <dl class="reason">${m.breakdown.map((b) => html`<dt>${b.criterion}</dt><dd><strong>${b.points === null ? "n/a" : `${b.points}/${b.max}`}</strong> - ${b.note}</dd>`)}</dl>
    </details>
    <a class="btn btn-sm" style="margin-top:12px" href="#/creator/${c.id}">View profile</a>
  </article>`;
}

async function viewDashboard() {
  if (!requireRole()) return;
  return state.user.role === "brand" ? brandDashboard() : creatorDashboard();
}

async function creatorDashboard() {
  render(html`<div class="page-head"><h1>Creator dashboard</h1><p>Welcome back, ${state.user.name}.</p></div><div id="dash" class="skeleton"></div>`);
  try {
    const [{ profile }, { campaigns }, { applications }] = await Promise.all([api("/profile"), api("/campaigns"), api("/applications")]);
    render(html`
    <div class="page-head"><h1>Creator dashboard</h1><p>Welcome back, ${state.user.name}.</p></div>
    ${profile.published ? "" : banner("Your profile isn't published yet. Complete the Portfolio Builder to appear in discovery and apply to campaigns.", "info")}
    <div class="grid">
      <div class="card"><div class="stat">${profile.published ? "Live" : "Draft"}</div><p class="muted">Profile status</p><a class="btn btn-sm" href="#/builder">${profile.published ? "Edit profile" : "Build profile"}</a></div>
      <div class="card"><div class="stat">${applications.length}</div><p class="muted">Applications sent</p></div>
      <div class="card"><div class="stat">${campaigns.length}</div><p class="muted">Open campaigns</p></div>
    </div>
    <section class="section"><h2>My applications</h2>
      ${applications.length ? html`<div class="grid">${applications.map((a) => html`<div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">${a.title}</h3><span class="badge ${a.status}">${a.status}</span></div>
        <p class="muted small">${a.brand_name} &middot; ${money(a.budget)} &middot; ${a.platform || "Any platform"}</p><p class="small">${a.message || "No message"}</p></div>`)}</div>`
        : html`<div class="empty">You haven't applied to any campaigns yet.</div>`}</section>
    <section class="section"><h2>Open campaigns</h2>
      ${campaigns.length ? html`<div class="grid">${campaigns.map((c) => html`<div class="card"><h3>${c.title}</h3><p class="muted small">${c.brand_name} &middot; ${c.niche} &middot; ${c.platform || "Any platform"} &middot; ${money(c.budget)}</p>
        <p class="small">${c.description}</p><p class="small muted">Content: ${c.content_type || "Any"} &middot; Audience: ${c.audience || "Any"}</p>
        ${c.my_application_status ? html`<span class="badge ${c.my_application_status}">Applied: ${c.my_application_status}</span>`
          : html`<form class="apply form" data-id="${c.id}"><label for="ap-${c.id}">Message to brand</label><textarea id="ap-${c.id}" name="message" maxlength="800" style="min-height:70px" placeholder="Why are you a great fit?"></textarea><button class="btn btn-primary btn-sm" type="submit">Apply</button></form>`}</div>`)}</div>`
        : html`<div class="empty">No open campaigns right now.</div>`}</section>`);
    $$(".apply").forEach((f) => f.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = $("button", f); setBusy(btn, true, "Sending...");
      try { await api(`/campaigns/${f.dataset.id}/apply`, { method: "POST", body: formData(f) }); toast("Application sent!"); creatorDashboard(); }
      catch (err) { toast(err.message, "error"); setBusy(btn, false); }
    }));
  } catch (e) { render(banner(e.message)); }
}

async function brandDashboard() {
  render(html`<div class="page-head"><h1>Brand dashboard</h1></div><div class="skeleton"></div>`);
  try {
    const [{ campaigns }, { creators: saved }] = await Promise.all([api("/campaigns"), api("/saved")]);
    render(html`
    <div class="page-head"><h1>Brand dashboard</h1><p>Welcome back, ${state.user.name}.</p></div>
    <div class="grid">
      <div class="card"><div class="stat">${campaigns.length}</div><p class="muted">Campaigns</p></div>
      <div class="card"><div class="stat">${campaigns.reduce((n, c) => n + c.application_count, 0)}</div><p class="muted">Applications received</p></div>
      <div class="card"><div class="stat">${saved.length}</div><p class="muted">Saved creators</p></div>
    </div>
    <section class="section card"><h2>Create a campaign</h2>
      <form id="campForm" class="form" novalidate>
        <div class="form-grid">
          <div><label for="k-title">Title *</label><input id="k-title" name="title" required maxlength="120"></div>
          <div><label for="k-niche">Niche *</label><select id="k-niche" name="niche">${options(NICHES)}</select></div>
          <div><label for="k-plat">Platform</label><select id="k-plat" name="platform">${options(PLATFORMS, "", "Any")}</select></div>
          <div><label for="k-budget">Budget (₹) *</label><input id="k-budget" name="budget" type="number" min="1" step="500" required></div>
          <div><label for="k-type">Content type</label><input id="k-type" name="content_type" placeholder="e.g. Product reviews"></div>
          <div><label for="k-aud">Target audience</label><input id="k-aud" name="audience"></div>
        </div>
        <div><label for="k-desc">Description</label><textarea id="k-desc" name="description"></textarea></div>
        <div id="kMsg" aria-live="polite"></div>
        <div><button class="btn btn-primary" type="submit">Create campaign</button></div>
      </form></section>
    <section class="section"><h2>My campaigns</h2>
      ${campaigns.length ? html`<div class="grid-2">${campaigns.map((c) => html`<div class="card" data-camp="${c.id}">
        <div class="row" style="justify-content:space-between"><h3 style="margin:0">${c.title}</h3><span class="badge ${c.status}">${c.status}</span></div>
        <p class="muted small">${c.niche} &middot; ${c.platform || "Any platform"} &middot; ${money(c.budget)} &middot; ${c.application_count} application(s)</p>
        <p class="small">${c.description}</p>
        <div class="row"><button class="btn btn-sm" data-apps="${c.id}" type="button">View applications</button>
          <button class="btn btn-sm" data-toggle="${c.id}" data-status="${c.status}" type="button">${c.status === "open" ? "Close" : "Reopen"}</button></div>
        <div class="apps" id="apps-${c.id}"></div></div>`)}</div>` : html`<div class="empty">No campaigns yet - create your first one above.</div>`}</section>
    <section class="section"><h2>Saved creators</h2>
      ${saved.length ? html`<div class="grid">${saved.map(creatorCard)}</div>` : html`<div class="empty">No saved creators. <a href="#/discover">Browse creators</a>.</div>`}</section>`);

    $("#campForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      const msg = $("#kMsg"); msg.innerHTML = "";
      try { await api("/campaigns", { method: "POST", body: formData(e.target) }); toast("Campaign created"); brandDashboard(); }
      catch (err) { msg.innerHTML = toStr(banner(err.message)); }
    });
    $$("[data-toggle]").forEach((b) => (b.onclick = async () => {
      try { await api("/campaigns/" + b.dataset.toggle, { method: "PATCH", body: { status: b.dataset.status === "open" ? "closed" : "open" } }); brandDashboard(); }
      catch (err) { toast(err.message, "error"); }
    }));
    $$("[data-apps]").forEach((b) => (b.onclick = () => loadApplications(b.dataset.apps)));
  } catch (e) { render(banner(e.message)); }
}

async function loadApplications(cid) {
  const box = $("#apps-" + cid);
  box.innerHTML = '<p class="muted small">Loading...</p>';
  try {
    const { applications } = await api(`/campaigns/${cid}/applications`);
    box.innerHTML = toStr(applications.length ? html`<table style="margin-top:12px">${applications.map((a) => html`<tr><td style="padding:8px 0">
      <a href="#/creator/${a.creator_id}"><strong>${a.name}</strong></a> <span class="muted small">${a.niche}</span><br><span class="small">${a.message || "No message"}</span></td>
      <td style="text-align:right;white-space:nowrap"><select class="appStatus" data-id="${a.id}" aria-label="Status for ${a.name}" style="width:auto">${options(["pending", "shortlisted", "accepted", "rejected"], a.status)}</select></td></tr>`)}</table>`
      : html`<p class="muted small" style="margin-top:12px">No applications yet.</p>`);
    $$(".appStatus", box).forEach((s) => (s.onchange = async () => {
      try { await api("/applications/" + s.dataset.id, { method: "PATCH", body: { status: s.value } }); toast("Status updated"); }
      catch (err) { toast(err.message, "error"); }
    }));
  } catch (e) { showError(box, e); }
}

/* ---------- Auth views ---------- */
function viewLogin() {
  render(html`
  <div class="page-head" style="text-align:center"><h1>Welcome back</h1></div>
  <form id="lf" class="card form" style="max-width:440px;margin:0 auto" novalidate>
    <div><label for="l-email">Email</label><input id="l-email" name="email" type="email" autocomplete="email" required></div>
    <div><label for="l-pw">Password</label><input id="l-pw" name="password" type="password" autocomplete="current-password" required></div>
    <div id="lMsg" aria-live="polite"></div>
    <button class="btn btn-primary" id="lBtn" type="submit">Log in</button>
    <hr style="border:0;border-top:1px solid var(--border);width:100%">
    <p class="muted small" style="margin:0">Presentation demo accounts:</p>
    <div class="row"><button type="button" class="btn btn-sm" data-demo="demo.creator@creatorconnect.ai">Demo creator</button>
      <button type="button" class="btn btn-sm" data-demo="demo.brand@creatorconnect.ai">Demo brand</button></div>
    <p class="muted small" style="margin:0">No account? <a href="#/register">Sign up</a></p>
  </form>`);
  async function doLogin(email, password, btn) {
    setBusy(btn, true, "Logging in...");
    try {
      const { user } = await api("/auth/login", { method: "POST", body: { email, password } });
      state.user = user; renderNav(); toast("Welcome, " + user.name); location.hash = "#/dashboard";
    } catch (e) { $("#lMsg").innerHTML = toStr(banner(e.message)); setBusy(btn, false); }
  }
  $("#lf").addEventListener("submit", (e) => { e.preventDefault(); const d = formData(e.target); doLogin(d.email, d.password, $("#lBtn")); });
  $$("[data-demo]").forEach((b) => (b.onclick = () => doLogin(b.dataset.demo, "Demo@1234", b)));
}

function viewRegister() {
  render(html`
  <div class="page-head" style="text-align:center"><h1>Create your account</h1></div>
  <form id="rf" class="card form" style="max-width:480px;margin:0 auto" novalidate>
    <fieldset style="border:0;padding:0;margin:0"><legend class="small" style="font-weight:600;margin-bottom:6px">I am a</legend>
      <div class="seg"><label><input type="radio" name="role" value="creator" checked><span>Creator</span></label><label><input type="radio" name="role" value="brand"><span>Brand / Agency</span></label></div></fieldset>
    <div><label for="r-name">Name or brand name</label><input id="r-name" name="name" autocomplete="name" required></div>
    <div><label for="r-email">Email</label><input id="r-email" name="email" type="email" autocomplete="email" required></div>
    <div><label for="r-pw">Password</label><input id="r-pw" name="password" type="password" autocomplete="new-password" required aria-describedby="r-hint"><div id="r-hint" class="hint">At least 8 characters with a letter and a number.</div></div>
    <div id="rMsg" aria-live="polite"></div>
    <button class="btn btn-primary" id="rBtn" type="submit">Create account</button>
    <p class="muted small" style="margin:0">Already registered? <a href="#/login">Log in</a></p>
  </form>`);
  $("#rf").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#rBtn"); setBusy(btn, true, "Creating...");
    try {
      const { user } = await api("/auth/register", { method: "POST", body: formData(e.target) });
      state.user = user; renderNav(); toast("Account created");
      location.hash = user.role === "creator" ? "#/builder" : "#/dashboard";
    } catch (err) { $("#rMsg").innerHTML = toStr(banner(err.message)); setBusy(btn, false); }
  });
}

/* ---------- Router ---------- */
const routes = [
  [/^#\/?$/, viewHome], [/^#\/discover$/, viewDiscover], [/^#\/creator\/(\d+)$/, viewCreator],
  [/^#\/builder$/, viewBuilder], [/^#\/content$/, viewContent], [/^#\/match$/, viewMatch],
  [/^#\/dashboard$/, viewDashboard], [/^#\/login$/, viewLogin], [/^#\/register$/, viewRegister],
];

async function router() {
  const hash = location.hash || "#/";
  $("#navLinks").classList.remove("open");
  $("#menuBtn").setAttribute("aria-expanded", "false");
  renderNav();
  for (const [re, fn] of routes) {
    const m = hash.match(re);
    if (m) { try { await fn(...m.slice(1)); } catch (e) { render(banner(e.message)); } $("#app").focus({ preventScroll: true }); return; }
  }
  render(html`<div class="empty"><h2>Page not found</h2><a class="btn" href="#/">Go home</a></div>`);
}

window.addEventListener("hashchange", router);
(async () => {
  try { state.user = (await api("/auth/me")).user; } catch { state.user = null; }
  router();
})();
